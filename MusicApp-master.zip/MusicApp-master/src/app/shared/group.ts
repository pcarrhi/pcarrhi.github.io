export interface Group {
    $key: string;
    groupName: string;
    groupMembers: number;
    groupLocation: string;
    groupInstrument: string;
}
